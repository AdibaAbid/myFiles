// function Emlpolyee(name, id, gender) {
//     this.gender = gender
//     this.name = name
//     this.id = id
// }
// var empolyeeOne = new Emlpolyee("ali", 123, "male")


function login() {
    window.location.replace("quiz.html")
}